package com.in28minutes.learn_spring_framework;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App02HelloWorldSpring {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
       var context = 
    		    new AnnotationConfigApplicationContext(HelloWorldConfiguraton.class);
       
       System.out.println(context.getBean("name"));
		
	}

}
