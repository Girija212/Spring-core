package com._minutes.springboot.learn._jpa_and_hibernate.course.jdbc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com._minutes.springboot.learn._jpa_and_hibernate.course.Course;
import com._minutes.springboot.learn._jpa_and_hibernate.course.springdatajpa.CourseSpringDataJpaRepository;

@Component
public class CourseJdbcCommandLineRunner implements CommandLineRunner {

   // @Autowired
    //private CourseJdbcRepository repository;

    @Autowired
    private CourseSpringDataJpaRepository repository;
    @Override
    public void run(String... args) throws Exception {
        repository.save(new Course(1, "Learn AWS jpa!", "in28minutes"));
        repository.save(new Course(2, "Learn Azure jpa!", "in28minutes"));
        repository.save(new Course(3, "Learn DevOps jpa!", "in28minutes"));

        repository.deleteById(1L);

        System.out.println(repository.findById(2L));
        System.out.println(repository.findById(3L));

        System.out.println(repository.findAll());
        System.out.println(repository.count()); 

        System.out.println(repository.findByAuthor("in28minutes"));
        System.out.println(repository.findByAuthor(""));

        System.out.println(repository.findByName("Learn Azure jpa!"));
        System.out.println(repository.findByName("Learn DevOps jpa!"));


    }

}
